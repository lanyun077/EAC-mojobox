/**
 * dsh-soul-md — browser half.
 *
 * Settings section (人设卡): a simple persona-card manager — type a card
 * name and content, save, and the plugin handles the rest. Plus a per-session
 * persona switcher in the conversation header and the new-session row.
 *
 * Hand-written ModuleLoader bundle — no build step required.
 */
window.__ModuleLoader__.load({
  id: "dsh-soul-md",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
    var react = require("react");
    var h = react.createElement;

    // ── CSS (theme tokens) ────────────────────────────────────────────────
    var CSS = ".__sm_root{max-width:640px;display:flex;flex-direction:column;gap:10px}" +
      ".__sm_field{display:flex;flex-direction:column;gap:4px}" +
      ".__sm_label{font-size:12px;font-weight:600;color:var(--dsw-alias-label-primary);display:flex;align-items:center;gap:6px}" +
      ".__sm_hint{font-size:11px;color:var(--dsw-alias-label-tertiary)}" +
      ".__sm_input{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);font:inherit;color:var(--dsw-alias-label-primary);border-radius:8px;padding:6px 10px;font-size:13px;box-sizing:border-box;width:100%}" +
      ".__sm_textarea{min-height:160px;resize:vertical;font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.6}" +
      ".__sm_row{display:flex;align-items:center;gap:8px}" +
      ".__sm_check{accent-color:var(--dsw-alias-state-business-primary)}" +
      ".__sm_actions{display:flex;gap:8px;align-items:center;margin-top:4px}" +
      ".__sm_btn{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);border-radius:8px;padding:6px 14px;font:inherit;font-size:13px;cursor:pointer}" +
      ".__sm_btn:hover:not(:disabled){border-color:var(--dsw-alias-state-business-primary)}" +
      ".__sm_btn:disabled{opacity:.5;cursor:default}" +
      ".__sm_btnPrimary{border-color:var(--dsw-alias-state-business-primary, #3964fe);background:var(--dsw-alias-state-business-primary, #3964fe);color:#fff}" +
      ".__sm_btnDanger{border-color:var(--dsw-alias-state-error-primary, #f85149);color:var(--dsw-alias-state-error-primary, #f85149)}" +
      ".__sm_status{font-size:12px;color:var(--dsw-alias-label-tertiary)}" +
      ".__sm_error{font-size:12px;color:var(--dsw-alias-state-error-primary)}" +
      ".__sm_unavailable{font-size:13px;color:var(--dsw-alias-label-tertiary)}" +
      ".__sm_group{border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;gap:8px}" +
      ".__sm_cardList{display:flex;flex-direction:column;gap:6px}" +
      ".__sm_cardRow{display:flex;align-items:center;gap:8px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:6px 10px}" +
      ".__sm_cardName{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
      ".__sm_cardPreview{font-size:11px;color:var(--dsw-alias-label-tertiary);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
      ".__sm_cardMemory{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;font-size:12px;color:var(--dsw-alias-label-secondary)}" +
      ".__sm_badge{border:1px solid var(--dsw-alias-state-business-primary);color:var(--dsw-alias-state-business-primary);border-radius:999px;padding:0 8px;font-size:10px;white-space:nowrap}" +
      ".__sm_switch{display:inline-flex;align-items:center;gap:6px;font-size:12px;margin-right:8px}" +
      ".__sm_switchLabel{color:var(--dsw-alias-label-tertiary);white-space:nowrap}" +
      ".__sm_switchSelect{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);border-radius:8px;padding:3px 6px;font:inherit;font-size:12px;max-width:180px}" +
      ".__sm_switchHero{margin-right:0;min-width:0}.__sm_switchHero .__sm_switchSelect{max-width:140px;min-width:0}";
    // Scoped flat controls retain native keyboard and form behavior.
    CSS += `
.dsh-flat.__sm_root{width:100%;max-width:720px;gap:14px;font-size:13px;line-height:1.65;color:var(--dsw-alias-label-primary);--flat-accent:var(--dsw-alias-state-business-primary,#3964fe);--flat-border:var(--dsw-alias-border-l2,#dce2eb)}
.dsh-flat.__sm_root *{box-sizing:border-box;min-width:0}
.dsh-flat.__sm_root p{margin:0}
.dsh-flat.__sm_root label[class$="_field"]{gap:7px}
.dsh-flat.__sm_root [class$="_label"]{font-size:13px;font-weight:500}
.dsh-flat.__sm_root [class$="_hint"]{font-size:12px;line-height:1.65}
.dsh-flat.__sm_root input:not([type=checkbox]),.dsh-flat.__sm_root select,.dsh-flat.__sm_root textarea{width:100%;border:1px solid var(--flat-border);border-radius:6px;background:var(--dsw-alias-bg-layer-3);color:inherit;font:inherit;padding:9px 12px;min-height:40px;box-shadow:none;transition:border-color .15s}
.dsh-flat.__sm_root input:hover:not(:disabled),.dsh-flat.__sm_root select:hover:not(:disabled),.dsh-flat.__sm_root textarea:hover:not(:disabled){border-color:var(--dsw-alias-label-tertiary)}
.dsh-flat.__sm_root select{appearance:none;padding-right:34px;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='m2 2 4 4 4-4' fill='none' stroke='%23778091' stroke-width='1.5'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center}
.dsh-flat.__sm_root input[type=checkbox]{appearance:none;flex:none;width:30px;height:18px;margin:0;border:1px solid var(--flat-border);border-radius:12px;background:var(--dsw-alias-bg-layer-2);position:relative;cursor:pointer;transition:background .15s,border-color .15s}
.dsh-flat.__sm_root input[type=checkbox]::before{content:"";position:absolute;left:2px;top:2px;width:12px;height:12px;border-radius:50%;background:var(--dsw-alias-label-secondary);transition:transform .15s}
.dsh-flat.__sm_root input[type=checkbox]:checked{background:var(--flat-accent);border-color:var(--flat-accent)}
.dsh-flat.__sm_root input[type=checkbox]:checked::before{transform:translateX(12px);background:#fff}
.dsh-flat.__sm_root :is(input,select,textarea,button,summary,a):focus-visible{outline:2px solid var(--flat-accent);outline-offset:3px}
.dsh-flat.__sm_root :is(input,select,textarea,button):disabled{opacity:.5;cursor:default}
.dsh-flat.__sm_root [class$="_actions"]{flex-wrap:wrap;gap:10px;margin-top:4px;padding-top:16px;border-top:1px solid var(--flat-border)}
.dsh-flat.__sm_root .__sm_group{border:0;border-top:1px solid var(--flat-border);border-radius:0;padding:20px 0 0;gap:14px}
.dsh-flat.__sm_root .__sm_cardRow{flex-wrap:wrap;border:0;border-bottom:1px solid var(--flat-border);border-radius:0;padding:10px 0;background:none}
.dsh-flat.__sm_root .__sm_cardPreview{flex-basis:100%;order:2}
.dsh-flat.__sm_root .__sm_textarea{font-family:ui-monospace,Consolas,monospace;line-height:1.7;min-height:180px;resize:vertical}
@media(max-width:480px){.dsh-flat.__sm_root{gap:16px}.dsh-flat.__sm_root .__sm_cardRow{gap:8px}}
@media(prefers-reduced-motion:reduce){.dsh-flat.__sm_root *,.dsh-flat.__sm_root input[type=checkbox]::before{transition:none}}
.dsh-flat.__sm_root button{border-radius:6px;min-height:34px;padding:7px 14px;font:inherit;font-size:12px;box-shadow:none}
.dsh-flat.__sm_root :is(h2,h3){margin:0;font-size:14px;font-weight:600}
`;
    var tagId = "dsh-soul-md/main.css";
    if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
      var tag = document.createElement("style");
      tag.dataset.plugin = "dsh-soul-md";
      tag.dataset.pluginCss = tagId;
      tag.textContent = CSS;
      document.head.appendChild(tag);
    }

    // ── locale ────────────────────────────────────────────────────────────
    var NS = "soulMd";
    var inject = ["slots", "locale", "configForms"];

    /**
     * Whether a namespace section now reflects every queued operation.
     *
     * A settled write says nothing about whether it was APPLIED: the scope
     * contract is "settle after the write and any recovery read", so a write the
     * Host refused with settings/conflict still resolves. Inspecting the section
     * afterwards is the only way to tell a committed change from a refused one.
     */
    function settingsOpsApplied(snapshot, ops) {
      if (!snapshot || snapshot.status !== "ready" || snapshot.value === void 0) return false;
      var user = snapshot.user && typeof snapshot.user === "object" ? snapshot.user : {};
      for (var i = 0; i < ops.length; i++) {
        var op = ops[i];
        var key = op.path[0];
        if (op.op === "unset") {
          if (key in user) return false;
        } else if (key === "memory" && op.value && typeof op.value === "object") {
          var actual = snapshot.value.memory;
          if (!actual || Object.keys(op.value).some(function (field) {
            return JSON.stringify(actual[field]) !== JSON.stringify(op.value[field]);
          })) return false;
        } else if (JSON.stringify(snapshot.value[key]) !== JSON.stringify(op.value)) {
          return false;
        }
      }
      return true;
    }

    /**
     * Apply one batch of namespace operations; resolves whether it took effect.
     *
     * One mutate() carries one revision fence and one persistence decision for
     * the whole batch. Issuing the same changes as separate set()/unset() calls
     * gives each its own fence, and a fence behind the Host document is refused —
     * so an edit could be rejected while the UI still reported success. Hosts
     * without mutate() apply the operations in order, each waiting for its
     * predecessor, which keeps the revision chain intact; never in parallel.
     */
    function commitSettingsOps(scope, ops) {
      if (ops.length === 0) return Promise.resolve(true);
      var run;
      if (typeof scope.mutate === "function") {
        run = scope.mutate(ops, scope.getSnapshot().revision);
      } else {
        run = ops.reduce(function (chain, op) {
          return chain.then(function () {
            return op.op === "unset" ? scope.unset(op.path[0]) : scope.set(op.path[0], op.value);
          });
        }, Promise.resolve());
      }
      return Promise.resolve(run).then(function () {
        return settingsOpsApplied(scope.getSnapshot(), ops);
      });
    }
    // The settings scope queues wire requests, but callers that build a whole
    // sessions map before that queue runs can otherwise overwrite each other.
    // Serialize plugin writes and construct session edits from the latest view.
    function createSettingsWriter(scope) {
      var tail = null;
      return function (ops) {
        function write() {
          try { return Promise.resolve(commitSettingsOps(scope, typeof ops === "function" ? ops() : ops)); }
          catch (error) { return Promise.reject(error); }
        }
        var pending = tail ? tail.then(write) : write();
        var current = pending.then(function () {}, function () {});
        tail = current;
        current.then(function () { if (tail === current) tail = null; });
        return pending;
      };
    }

    // The host exposes one composer block per session, shared with other
    // plugins. Never replace someone else's block or clear one we do not own.
    function holdComposer(blocks, sessionId, reason) {
      if (!blocks || typeof blocks.storeFor !== "function" || typeof blocks.set !== "function") return function () {};
      var store = blocks.storeFor(sessionId);
      if (!store || typeof store.getSnapshot !== "function" || typeof store.subscribe !== "function") return function () {};
      var block = { reason: reason };
      var active = true;
      var ensure = function () {
        if (active && store.getSnapshot() === void 0) blocks.set(sessionId, block);
      };
      var unsubscribe = store.subscribe(ensure);
      ensure();
      return function () {
        if (!active) return;
        active = false;
        unsubscribe();
        if (store.getSnapshot() === block) blocks.set(sessionId, void 0);
      };
    }
    var zh = {
      nav: "人设卡",
      confirmDelete: '删除人设卡“{name}”？',
      invalidCardName: "请输入人设卡名称",
      invalidCardContent: "请输入人设卡内容",
      intro: "输入人设卡名称和内容，保存后插件自动管理。人设按会话选择 → 工作区人设 → 默认卡解析，可在新会话页或聊天标题栏切换。",
      cardListTitle: "人设卡",
      cardListHint: "卡片内容会注入系统提示词；可为每个会话单独选卡。",
      cardMemoryLabel: "记忆",
      cardMemoryAria: "启用 {name} 的记忆",
      cardMemoryHint: "每张卡可单独关闭记忆：关闭后不再注入，也不能使用记忆工具；已有文件保留。当前会话中先前注入的内容仍可能存在，彻底隔离请新建会话。",
      showPersonaSwitcher: "显示会话人设选择器",
      showPersonaSwitcherHint: "更改后立即保存。关闭后新会话页和聊天标题栏都不显示；已有会话选择不受影响。",
      cardName: "人设卡名称",
      cardNameHint: "给这张人设卡起个名字（如：希希芙、工作狂助手）。",
      cardContent: "人设卡内容（Markdown）",
      cardContentHint: "角色设定、说话风格、工作准则……AI 会用 soul_read / soul_update 自己读和演化这张卡。",
      saveCard: "保存人设卡",
      save: "保存",
      editCard: "编辑",
      deleteCard: "删除",
      setDefault: "设为默认",
      defaultBadge: "默认",
      emptyCards: "还没有人设卡——先在上面保存一张吧。",
      noActive: "（未设置默认卡，人设未启用）",
      activeHint: "没有会话级选择时使用的人设卡；选「不启用」则默认关闭人设。",
      noneOption: "不启用",
      autoOption: "自动（跟随工作区或默认卡）",
      saved: "已保存",
      saving: "保存中…",
      error: "操作失败",
      notApplied: "写入未生效，请检查当前设置",
      invalidMemoryNumber: "字符上限和文件大小上限必须是大于零的整数",
      unavailable: "设置命名空间不可用（服务端未注册 soul-md 命名空间？）",
      loading: "加载中…",
      memoryTitle: "长期记忆（插件托管）",
      memoryIntro: "AI 用 memory_append / memory_read / memory_rewrite 读写记忆：当前人设卡有自己的记忆，没选卡时用全局记忆。记忆文件由插件自动管理。",
      memoryInjectHint: "把记忆渲染为 soul:memory 提示词段落（AI 可随时读到记忆）。",
      memoryLayeredHint: "默认开启。优先保留 topics/*.md 的标题和摘要索引；core.md 超过注入上限时保留首尾。AI 可用 memory_read(topic) 按需读取全文。",
      fieldMemoryRecall: "自动关键词召回",
      memoryRecallHint: "默认使用关键词；从第二条用户消息起检索主题正文，只提示 key 和摘要。关键词匹配不等于语义检索。",
      fieldMemoryRecallPlacement: "召回注入位置",
      memoryRecallPlacementHint: "默认使用运行时上下文以保留稳定的提示词前缀；宿主禁用或不支持时回退到系统提示词。",
      recallPlacementContext: "运行时上下文（默认）", recallPlacementSystem: "系统提示词",
      fieldMemoryIndexMode: "注入主题索引",
      memoryIndexModeHint: "默认全量索引；仅召回模式须开启关键词召回，可减少主题多时的每轮开销。memory_read 仍返回完整索引。",
      fieldMemoryCompactionRecall: "压缩后补偿已查阅主题",
      memoryCompactionRecallHint: "默认开启；成功压缩或裁剪后的下一条用户消息，提示本会话已读写主题的 key 和摘要。仅在当前进程有效，不注入全文。",
      fieldMemoryRecallMaxTopics: "每组召回主题上限（最多 20）",
      fieldMemoryRecallMaxChars: "召回与压缩补偿总字符上限（最多 8000）",
      recallOff: "关闭", recallKeyword: "关键词", indexAll: "全量索引", indexRecall: "仅召回",
      skipSubagentsHint: "默认开启。DSH 以 origin: \"subagent\" 创建的委派子会话不再自动接收人设与记忆；子代理的工具仍使用它原本的人设卡与记忆作用域。",
      allowTemplatesHint: "默认关闭，花括号原样保留。仅当卡片或记忆需要使用 {{cwd}} 等宿主变量时开启；未知变量仍会使提示词渲染失败。",
      memoryMaxCharsHint: "注入段落的字符上限；超限时保留首尾，全文可用 memory_read 读取。",
      memoryMaxBytesHint: "单份记忆文件大小上限。",
      switchLabel: "人设",
      switchTitle: "切换当前会话的人设（会话级，优先于工作区/默认卡）",
      heroSwitchTitle: "选择当前会话的人设。切换工作区可能打开另一个会话，请确认人设。",
      savingPersona: "正在保存会话人设…",
      wsTitle: "工作区人设",
      wsHint: "给每个工作区指定人设卡：该工作区的会话默认使用这张卡（会话级切换仍然优先）。",
      wsFollow: "跟随默认卡",
      wsEmpty: "还没有工作区记录——在会话页新建/选择一个工作区后，这里会出现它的设置。",
      wsName: "工作区",
      fieldMemoryInject: "注入为 soul:memory 提示词段落",
      fieldMemoryLayered: "启用分层记忆（core + topics 索引）",
      fieldSkipSubagents: "子代理会话跳过人设与记忆注入",
      fieldAllowTemplates: "允许人设与记忆使用提示词变量",
      fieldMemoryInjectMaxChars: "注入字符上限",
      fieldMemoryMaxBytes: "记忆文件大小上限",
      cardNamePlaceholder: "希希芙"
    };
    var en = {
      nav: "Persona Card",
      confirmDelete: 'Delete persona card "{name}"?',
      invalidCardName: "Enter a persona card name",
      invalidCardContent: "Enter persona card content",
      intro: "Save a persona card and the plugin manages its files. Persona resolves as session choice > workspace persona > default card; choose one on the new-session page or in the conversation header.",
      cardListTitle: "Persona cards",
      cardListHint: "Card content is injected into the system prompt; choose one for each session.",
      cardMemoryLabel: "Memory",
      cardMemoryAria: "Enable memory for {name}",
      cardMemoryHint: "Turn memory off per card to stop injection and memory-tool access; existing files are kept. Earlier content may remain in the current conversation, so start a new session for isolation.",
      showPersonaSwitcher: "Show the session persona selector",
      showPersonaSwitcherHint: "Changes save immediately. Turning this off hides both selectors and preserves existing session choices.",
      cardName: "Card name",
      cardNameHint: "A name for this card (e.g. 希希芙, workaholic-assistant).",
      cardContent: "Card content (Markdown)",
      cardContentHint: "Role, speaking style, work rules… the AI reads and evolves this card itself via soul_read / soul_update.",
      saveCard: "Save card",
      save: "Save",
      editCard: "Edit",
      deleteCard: "Delete",
      setDefault: "Set default",
      defaultBadge: "default",
      emptyCards: "No persona cards yet — save one above first.",
      noActive: "(no default card; persona disabled)",
      activeHint: "The card used when a session has no explicit choice; pick \"disabled\" to turn the persona off by default.",
      noneOption: "Disabled",
      autoOption: "Auto (workspace or default)",
      saved: "Saved",
      saving: "Saving…",
      error: "Operation failed",
      notApplied: "Write did not take effect; check the current settings",
      invalidMemoryNumber: "The character and file size caps must be positive integers",
      unavailable: "Settings namespace unavailable (soul-md namespace not registered server-side?)",
      loading: "Loading…",
      memoryTitle: "Long-term memory (plugin-managed)",
      memoryIntro: "The AI reads/writes memory with memory_append / memory_read / memory_rewrite: the active persona card has its own memory, otherwise the global memory is used. Files are managed by the plugin.",
      memoryInjectHint: "Also render the memory as the soul:memory prompt section (the agent always sees its memory).",
      memoryLayeredHint: "On by default. The topics/*.md title and summary index takes priority; if core.md exceeds the injection cap, its beginning and end remain visible. memory_read(topic) retrieves full topic text on demand.",
      fieldMemoryRecall: "Automatic keyword recall",
      memoryRecallHint: "Keyword recall is on by default. From the second user message, search topic bodies and inject keys and summaries only. Lexical matching is not semantic search.",
      fieldMemoryRecallPlacement: "Recall placement",
      memoryRecallPlacementHint: "Runtime context preserves the stable prompt prefix by default. Falls back to the system prompt when the host disables or does not support runtime context.",
      recallPlacementContext: "Runtime context (default)", recallPlacementSystem: "System prompt",
      fieldMemoryIndexMode: "Injected topic index",
      memoryIndexModeHint: "Full index by default. Recall-only mode requires keyword recall and reduces per-turn topic overhead. memory_read still returns the full index.",
      fieldMemoryCompactionRecall: "Recall consulted topics after compaction",
      memoryCompactionRecallHint: "On by default. The next user message after successful compaction/pruning restores keys and summaries of topics read/written in this session. Process-local; no full bodies injected.",
      fieldMemoryRecallMaxTopics: "Topic limit per recall group (up to 20)",
      fieldMemoryRecallMaxChars: "Combined recall/recovery character cap (up to 8000)",
      recallOff: "Off", recallKeyword: "Keyword", indexAll: "Full index", indexRecall: "Recall only",
      skipSubagentsHint: "On by default. Sessions DSH created as delegated children (origin: subagent) do not automatically receive persona or memory prompts. Child tools keep the same persona card and memory scope.",
      allowTemplatesHint: "Off by default so braces remain literal. Enable only if cards or memory need host variables such as {{cwd}}; unknown variables will still fail prompt rendering.",
      memoryMaxCharsHint: "Cap for the injected section (chars); truncation retains both ends. Use memory_read for the full text.",
      memoryMaxBytesHint: "Max size of one memory file.",
      switchLabel: "Persona",
      switchTitle: "Switch this session's persona (session-level, overrides workspace/default)",
      heroSwitchTitle: "Choose this session's persona. Switching workspaces may open another session; check its selection.",
      savingPersona: "Saving session persona…",
      wsTitle: "Workspace personas",
      wsHint: "Assign a persona card per workspace: sessions of that workspace use it by default (session-level switching still wins).",
      wsFollow: "Follow default",
      wsEmpty: "No workspace records yet — create/select a workspace in the session page and its setting appears here.",
      wsName: "Workspace",
      fieldMemoryInject: "Inject as soul:memory prompt section",
      fieldMemoryLayered: "Enable layered memory (core + topic index)",
      fieldSkipSubagents: "Skip persona + memory in subagent sessions",
      fieldAllowTemplates: "Allow prompt variables in persona and memory",
      fieldMemoryInjectMaxChars: "Inject char cap",
      fieldMemoryMaxBytes: "Memory file size cap",
      cardNamePlaceholder: "Xixifu"
    };

    var MEMORY_FIELDS = [
      { key: "inject", label: "fieldMemoryInject", type: "checkbox", hint: "memoryInjectHint" },
      { key: "layered", label: "fieldMemoryLayered", type: "checkbox", hint: "memoryLayeredHint" },
      { key: "recall", label: "fieldMemoryRecall", type: "select", options: [["off", "recallOff"], ["keyword", "recallKeyword"]], hint: "memoryRecallHint" },
      { key: "recallPlacement", label: "fieldMemoryRecallPlacement", type: "select", options: [["context", "recallPlacementContext"], ["system", "recallPlacementSystem"]], hint: "memoryRecallPlacementHint" },
      { key: "indexMode", label: "fieldMemoryIndexMode", type: "select", options: [["all", "indexAll"], ["recall", "indexRecall"]], hint: "memoryIndexModeHint" },
      { key: "compactionRecall", label: "fieldMemoryCompactionRecall", type: "checkbox", hint: "memoryCompactionRecallHint" },
      { key: "recallMaxTopics", label: "fieldMemoryRecallMaxTopics", type: "number", max: 20 },
      { key: "recallMaxChars", label: "fieldMemoryRecallMaxChars", type: "number", max: 8000 },
      { key: "injectMaxChars", label: "fieldMemoryInjectMaxChars", type: "number", hint: "memoryMaxCharsHint" },
      { key: "maxBytes", label: "fieldMemoryMaxBytes", type: "number", hint: "memoryMaxBytesHint" }
    ];
    var MEMORY_DEFAULTS = { inject: true, layered: true, recall: "keyword", recallPlacement: "context", indexMode: "all", compactionRecall: true, recallMaxTopics: 5, recallMaxChars: 1600, injectMaxChars: 8000, maxBytes: 1048576 };

    function SoulSection(props) {
      useLocale(props.locale);
      var t = props.t;
      var scope = props.scope;
      var [snapshot, setSnapshot] = react.useState(function () { return scope.getSnapshot(); });
      var ready = snapshot.status === "ready" && snapshot.value !== void 0;
      var [cardDraft, setCardDraft] = react.useState({ name: "", content: "" });
      var [memDraft, setMemDraft] = react.useState({});
      var [skipDraft, setSkipDraft] = react.useState(null);
      var [templatesDraft, setTemplatesDraft] = react.useState(null);
      var [switcherDraft, setSwitcherDraft] = react.useState(null);
      var [busy, setBusy] = react.useState(false);
      var writePending = react.useRef(false);
      var [notice, setNotice] = react.useState(null);
      var [error, setError] = react.useState(null);

      react.useEffect(function () {
        // No refresh call here: the scope's public seam has no load(). Reads ride
        // the shared describe mirror, which re-reads on every Host
        // `settings/document-updated`; a guarded scope.load() was dead code that
        // only looked like a refresh.
        var alive = true;
        var sync = function () { if (alive) setSnapshot(scope.getSnapshot()); };
        var un = typeof scope.subscribe === "function" ? scope.subscribe(sync) : null;
        // The settings scope is bound once for this plugin and shared across
        // every mount of the section. Unmounting must only unsubscribe — never
        // dispose the scope, or a later remount finds a `disposed` scope whose
        // write queue no-ops, silently dropping saves.
        return function () { alive = false; if (un) un(); };
      }, [scope]);

      if (snapshot.status === "unavailable") {
        return h("p", { className: "__sm_unavailable" }, t("unavailable"));
      }
      if (!ready) return h("p", { className: "__sm_status" }, t("loading"));

      var value = snapshot.value;
      var cards = value.cards && typeof value.cards === "object" ? value.cards : {};
      var cardNames = Object.keys(cards).sort();
      var active = typeof value.active === "string" ? value.active : "";
      var wsList = Array.isArray(value.workspaceList) ? value.workspaceList : [];
      var wsMap = value.workspaces && typeof value.workspaces === "object" ? value.workspaces : {};
      var disabledCards = Array.isArray(value.memory?.disabledCards) ? value.memory.disabledCards : [];

      function setNotice0() { setNotice(null); setError(null); }

      /**
       * One write path for every field of this section.
       *
       * Reports success only when the namespace section confirms the change, so a
       * refused write can no longer masquerade as "saved"; on failure the form is
       * reloaded from whatever the Host actually holds.
       */
      function runWrite(ops, onOk) {
        if (writePending.current) return;
        writePending.current = true;
        setBusy(true); setNotice0();
        props.write(ops).then(function (ok) {
          writePending.current = false;
          setBusy(false);
          setSnapshot(scope.getSnapshot());
          if (!ok) {
            setError({ key: "error", detailKey: "notApplied" });
            setMemDraft(function () { return {}; });
            setSkipDraft(null);
            setSwitcherDraft(null);
            return;
          }
          setNotice({ key: "saved" });
          if (onOk) onOk();
        }).catch(function (e) {
          writePending.current = false;
          setBusy(false); setSnapshot(scope.getSnapshot());
          setSwitcherDraft(null);
          setError({ key: "error", detail: String(e && e.message || e) });
        });
      }

      function onWsChange(path, v) {
        var next = Object.assign({}, wsMap);
        if (v === "") delete next[path];
        else next[path] = v;
        runWrite([{ op: "set", path: ["workspaces"], value: next }]);
      }

      function onSaveCard() {
        var name = String(cardDraft.name || "").trim();
        var content = String(cardDraft.content || "");
        if (!name) { setError({ key: "error", detailKey: "invalidCardName" }); return; }
        if (!content.trim()) { setError({ key: "error", detailKey: "invalidCardContent" }); return; }
        var next = Object.assign({}, cards);
        next[name] = content;
        runWrite([{ op: "set", path: ["cards"], value: next }], function () {
          setCardDraft({ name: "", content: "" });
        });
      }

      function onEditCard(name) {
        setCardDraft({ name: name, content: cards[name] || "" });
        setNotice0();
      }

      function onDeleteCard(name) {
        if (!window.confirm(t("confirmDelete", { name: name }))) return;
        var next = Object.assign({}, cards);
        delete next[name];
        // Deleting the active card also clears `active`. Both edits go in ONE
        // batch: as two independent writes each carried its own revision fence
        // and the second could be refused for a revision the first had just
        // superseded.
        var ops = [{ op: "set", path: ["cards"], value: next }];
        if (name === active) ops.push({ op: "unset", path: ["active"] });
        if (disabledCards.indexOf(name) !== -1) ops.push({ op: "set", path: ["memory"], value:
          Object.assign({}, value.memory || {}, { disabledCards: disabledCards.filter(function (item) { return item !== name; }) }) });
        runWrite(ops);
      }

      function onCardMemory(name, enabled) {
        var next = disabledCards.filter(function (item) { return item !== name; });
        if (!enabled) next.push(name);
        runWrite([{ op: "set", path: ["memory"], value: Object.assign({}, value.memory || {}, { disabledCards: next }) }]);
      }

      function onSetActive(name) {
        runWrite([{ op: "set", path: ["active"], value: name }]);
      }

      function skipValue() { return skipDraft !== null ? skipDraft : Boolean(value.skipSubagents ?? true); }
      function templatesValue() { return templatesDraft !== null ? templatesDraft : Boolean(value.allowTemplates); }
      function memDraftValue(f) {
        var m = memDraft[f.key];
        if (f.type === "checkbox") return m !== void 0 ? m : Boolean(value.memory?.[f.key] ?? MEMORY_DEFAULTS[f.key]);
        return m !== void 0 ? m : String(value.memory?.[f.key] ?? MEMORY_DEFAULTS[f.key]);
      }
      function setMemField(f, v) {
        setMemDraft(function (prev) { var next = Object.assign({}, prev); next[f.key] = v; return next; });
        setNotice0();
      }
      function memNext() {
        var out = {};
        MEMORY_FIELDS.forEach(function (f) {
          var cur = memDraftValue(f);
          if (f.type === "checkbox") out[f.key] = Boolean(cur);
          else if (f.type === "select") {
            if (f.options.some(function (option) { return option[0] === cur; })) out[f.key] = cur;
          }
          else {
            var number = Number(cur);
            if (String(cur).trim() === "" || !Number.isSafeInteger(number) || number < 1 || (f.max && number > f.max)) return;
            out[f.key] = number;
          }
        });
        return Object.keys(out).length === MEMORY_FIELDS.length ? out : null;
      }
      function memBase() {
        var out = {};
        MEMORY_FIELDS.forEach(function (f) {
          var cur = value.memory?.[f.key] ?? MEMORY_DEFAULTS[f.key];
          out[f.key] = f.type === "checkbox" ? Boolean(cur) : f.type === "select" ? String(cur) : Number(cur);
        });
        return out;
      }
      function onSaveMemory() {
        var next = memNext();
        if (!next) { setError({ key: "error", detailKey: "invalidMemoryNumber" }); return; }
        var base = memBase();
        var nextSkip = skipValue();
        var baseSkip = Boolean(value.skipSubagents ?? true);
        var nextTemplates = templatesValue();
        var baseTemplates = Boolean(value.allowTemplates);
        if (JSON.stringify(next) === JSON.stringify(base) && nextSkip === baseSkip && nextTemplates === baseTemplates) {
          setBusy(false); setNotice({ key: "saved" });
          return;
        }
        var ops = [];
        if (JSON.stringify(next) !== JSON.stringify(base)) ops.push({ op: "set", path: ["memory"], value: Object.assign({}, value.memory || {}, next) });
        if (nextSkip !== baseSkip) ops.push({ op: "set", path: ["skipSubagents"], value: nextSkip });
        if (nextTemplates !== baseTemplates) ops.push({ op: "set", path: ["allowTemplates"], value: nextTemplates });
        runWrite(ops, function () { setMemDraft(function () { return {}; }); setSkipDraft(null); setTemplatesDraft(null); });
      }

      return h("div", { className: "__sm_root dsh-flat" },
        h("p", { className: "__sm_hint", style: { margin: "0 0 4px" } }, t("intro")),

        // ── card form ────────────────────────────────────────────────────
        h("div", { className: "__sm_group" },
          h("label", { className: "__sm_field" },
            h("span", { className: "__sm_label" }, t("cardName")),
            h("span", { className: "__sm_hint" }, t("cardNameHint")),
            h("input", { className: "__sm_input", type: "text", value: cardDraft.name, placeholder: t("cardNamePlaceholder"), onChange: function (e) { setCardDraft(function (p) { return Object.assign({}, p, { name: e.target.value }); }); setNotice0(); } })
          ),
          h("label", { className: "__sm_field" },
            h("span", { className: "__sm_label" }, t("cardContent")),
            h("span", { className: "__sm_hint" }, t("cardContentHint")),
            h("textarea", { className: "__sm_input __sm_textarea", value: cardDraft.content, onChange: function (e) { setCardDraft(function (p) { return Object.assign({}, p, { content: e.target.value }); }); setNotice0(); } })
          ),
          h("div", { className: "__sm_actions" },
            h("button", { type: "button", className: "__sm_btn __sm_btnPrimary", onClick: onSaveCard, disabled: busy }, t("saveCard")),
            notice ? h("span", { className: "__sm_status" }, messageText(t, notice)) : null,
            busy ? h("span", { className: "__sm_status" }, t("saving")) : null,
            error ? h("span", { className: "__sm_error" }, messageText(t, error)) : null
          )
        ),

        // ── card list + default picker ───────────────────────────────────
        h("div", { className: "__sm_group" },
          h("p", { className: "__sm_label", style: { margin: 0 } }, t("cardListTitle")),
          h("p", { className: "__sm_hint", style: { margin: "0 0 2px" } }, t("cardListHint")),
          h("p", { className: "__sm_hint" }, t("cardMemoryHint")),
          h("label", { className: "__sm_field" },
            h("span", { className: "__sm_row" },
              h("input", { className: "__sm_check", type: "checkbox", checked: switcherDraft !== null ? switcherDraft : value.showPersonaSwitcher !== false, disabled: busy, onChange: function (e) {
                if (writePending.current) return;
                var checked = e.target.checked;
                setSwitcherDraft(checked);
                runWrite([{ op: "set", path: ["showPersonaSwitcher"], value: checked }], function () { setSwitcherDraft(null); });
              } }),
              h("span", { className: "__sm_label" }, t("showPersonaSwitcher"))
            ),
            h("span", { className: "__sm_hint" }, t("showPersonaSwitcherHint")),
            error ? h("span", { className: "__sm_error", role: "alert" }, messageText(t, error)) : null
          ),
          h("label", { className: "__sm_field" },
            h("span", { className: "__sm_label" }, t("defaultBadge")),
            h("span", { className: "__sm_hint" }, t("activeHint")),
            h("select", { className: "__sm_input", value: active || "", disabled: busy, onChange: function (e) { var v = e.target.value; if (!v) runWrite([{ op: "unset", path: ["active"] }]); else onSetActive(v); } },
              h("option", { value: "" }, t("noneOption")),
              cardNames.map(function (n) { return h("option", { key: n, value: n }, n); })
            )
          ),
          cardNames.length === 0
            ? h("p", { className: "__sm_hint" }, t("emptyCards"))
            : h("div", { className: "__sm_cardList" },
                cardNames.map(function (n) {
                  var preview = String(cards[n] || "").split("\n").filter(Boolean)[0] || "";
                  return h("div", { key: n, className: "__sm_cardRow" },
                    h("span", { className: "__sm_cardName", title: n }, n),
                    n === active ? h("span", { className: "__sm_badge" }, t("defaultBadge")) : null,
                    h("span", { className: "__sm_cardPreview" }, preview),
                    h("label", { className: "__sm_cardMemory" },
                      h("input", { className: "__sm_check", type: "checkbox", checked: disabledCards.indexOf(n) === -1,
                        disabled: busy, "aria-label": t("cardMemoryAria", { name: n }),
                        onChange: function (e) { onCardMemory(n, e.target.checked); } }),
                      h("span", null, t("cardMemoryLabel"))
                    ),
                    h("button", { type: "button", className: "__sm_btn", onClick: function () { onEditCard(n); }, disabled: busy }, t("editCard")),
                    n === active ? null : h("button", { type: "button", className: "__sm_btn", onClick: function () { onSetActive(n); }, disabled: busy }, t("setDefault")),
                    h("button", { type: "button", className: "__sm_btn __sm_btnDanger", onClick: function () { onDeleteCard(n); }, disabled: busy }, t("deleteCard"))
                  );
                })
              )
        ),

        // ── per-workspace persona mapping ────────────────────────────────
        h("div", { className: "__sm_group" },
          h("p", { className: "__sm_label", style: { margin: 0 } }, t("wsTitle")),
          h("p", { className: "__sm_hint", style: { margin: "0 0 2px" } }, t("wsHint")),
          wsList.length === 0
            ? h("p", { className: "__sm_hint" }, t("wsEmpty"))
            : h("div", { className: "__sm_cardList" },
                wsList.map(function (ws) {
                  var current = wsMap[ws.path] || "";
                  if (current && current !== "none" && !(current in cards)) current = "";
                  return h("label", { key: ws.path, className: "__sm_field" },
                    h("span", { className: "__sm_label", title: ws.path }, (ws.title || ws.path)),
                    h("select", { className: "__sm_input", value: current, disabled: busy, onChange: function (e) { onWsChange(ws.path, e.target.value); } },
                      h("option", { value: "" }, t("wsFollow")),
                      h("option", { value: "none" }, t("noneOption")),
                      cardNames.map(function (n) { return h("option", { key: n, value: n }, n); })
                    )
                  );
                })
              ),
          error ? h("span", { className: "__sm_error", role: "alert" }, messageText(t, error)) : null
        ),

        // ── memory (plugin-managed) ──────────────────────────────────────
        h("div", { className: "__sm_group" },
          h("p", { className: "__sm_label", style: { margin: 0 } }, t("memoryTitle")),
          h("p", { className: "__sm_hint", style: { margin: "0 0 2px" } }, t("memoryIntro")),
          h("label", { className: "__sm_field" },
            h("span", { className: "__sm_row" },
              h("input", { className: "__sm_check", type: "checkbox", checked: skipValue(), onChange: function (e) { setSkipDraft(e.target.checked); setNotice0(); } }),
              h("span", { className: "__sm_label" }, t("fieldSkipSubagents"))
            ),
            h("span", { className: "__sm_hint" }, t("skipSubagentsHint"))
          ),
          h("label", { className: "__sm_field" },
            h("span", { className: "__sm_row" },
              h("input", { className: "__sm_check", type: "checkbox", checked: templatesValue(), onChange: function (e) { setTemplatesDraft(e.target.checked); setNotice0(); } }),
              h("span", { className: "__sm_label" }, t("fieldAllowTemplates"))
            ),
            h("span", { className: "__sm_hint" }, t("allowTemplatesHint"))
          ),
          MEMORY_FIELDS.map(function (f) {
            if (f.type === "select") {
              return h("label", { key: f.key, className: "__sm_field" },
                h("span", { className: "__sm_label" }, t(f.label)),
                h("select", { className: "__sm_input", value: memDraftValue(f), onChange: function (e) { setMemField(f, e.target.value); } },
                  f.options.map(function (option) { return h("option", { key: option[0], value: option[0] }, t(option[1])); })),
                f.hint ? h("span", { className: "__sm_hint" }, t(f.hint)) : null
              );
            }
            if (f.type === "checkbox") {
              return h("label", { key: f.key, className: "__sm_field" },
                h("span", { className: "__sm_row" },
                  h("input", { className: "__sm_check", type: "checkbox", checked: Boolean(memDraftValue(f)), onChange: function (e) { setMemField(f, e.target.checked); } }),
                  h("span", { className: "__sm_label" }, t(f.label))
                ),
                f.hint ? h("span", { className: "__sm_hint" }, t(f.hint)) : null
              );
            }
            return h("label", { key: f.key, className: "__sm_field" },
              h("span", { className: "__sm_label" }, t(f.label)),
              h("input", { className: "__sm_input", type: "number", min: 1, max: f.max, step: 1, value: memDraftValue(f), onChange: function (e) { setMemField(f, e.target.value); } }),
              f.hint ? h("span", { className: "__sm_hint" }, t(f.hint)) : null
            );
          }),
          h("div", { className: "__sm_actions" },
            h("button", { type: "button", className: "__sm_btn __sm_btnPrimary", onClick: onSaveMemory, disabled: busy }, t("save")),
            notice ? h("span", { className: "__sm_status" }, messageText(t, notice)) : null,
            busy ? h("span", { className: "__sm_status" }, t("saving")) : null,
            error ? h("span", { className: "__sm_error" }, messageText(t, error)) : null
          )
        )
      );
    }

    // ── per-session persona switcher ───────────────────────────────────────
    function PersonaSwitcher(props) {
      useLocale(props.locale);
      var t = props.t;
      var scope = props.scope;
      var sessionId = props.sessionId;
      var [snapshot, setSnapshot] = react.useState(function () { return scope.getSnapshot(); });
      var [busy, setBusy] = react.useState(false);
      var [error, setError] = react.useState(null);
      var [draft, setDraft] = react.useState(null);
      var writePending = react.useRef(false);
      react.useEffect(function () {
        // No refresh call here: the scope's public seam has no load(). Reads ride
        // the shared describe mirror, which re-reads on every Host
        // `settings/document-updated`; a guarded scope.load() was dead code that
        // only looked like a refresh.
        var alive = true;
        var sync = function () { if (alive) setSnapshot(scope.getSnapshot()); };
        var un = typeof scope.subscribe === "function" ? scope.subscribe(sync) : null;
        // The settings scope is bound once for this plugin and shared across
        // every mount of the section. Unmounting must only unsubscribe — never
        // dispose the scope, or a later remount finds a `disposed` scope whose
        // write queue no-ops, silently dropping saves.
        return function () { alive = false; if (un) un(); };
      }, [scope]);
      var ready = snapshot.status === "ready" && snapshot.value !== void 0;
      if (!ready || !sessionId || snapshot.value.showPersonaSwitcher === false) return null;
      var value = snapshot.value;
      var cards = value.cards && typeof value.cards === "object" ? value.cards : {};
      var sessions = value.sessions && typeof value.sessions === "object" ? value.sessions : {};
      var choice = sessions[sessionId] || "";
      if (choice && choice !== "none" && !(choice in cards)) choice = "";
      var cardNames = Object.keys(cards).sort();
      function onChange(e) {
        if (writePending.current) return;
        writePending.current = true;
        setBusy(true);
        setError(null);
        var v = e.target.value;
        setDraft(v);
        var release = props.hero ? props.holdComposer(sessionId, t("savingPersona")) : function () {};
        props.write(function () {
          var current = scope.getSnapshot();
          if (!current || current.status !== "ready" || !current.value) throw new Error(t("unavailable"));
          var next = Object.assign({}, current.value.sessions || {});
          if (v === "") delete next[sessionId];
          else next[sessionId] = v;
          return [{ op: "set", path: ["sessions"], value: next }];
        }).then(function (ok) {
          writePending.current = false;
          setBusy(false);
          setDraft(null);
          setSnapshot(scope.getSnapshot());
          if (!ok) setError({ key: "error", detailKey: "notApplied" });
        }).catch(function (e) {
          writePending.current = false;
          setBusy(false);
          setDraft(null);
          setSnapshot(scope.getSnapshot());
          setError({ key: "error", detail: String(e && e.message || e) });
        }).finally(release);
      }
      return h("label", { className: props.hero ? "__sm_switch __sm_switchHero" : "__sm_switch", title: t(props.hero ? "heroSwitchTitle" : "switchTitle") },
        h("span", { className: "__sm_switchLabel" }, t("switchLabel")),
        h("select", { className: "__sm_switchSelect", value: draft !== null ? draft : choice, disabled: busy, onChange: onChange },
          h("option", { value: "" }, t("autoOption")),
          h("option", { value: "none" }, t("noneOption")),
          cardNames.map(function (n) {
            return h("option", { key: n, value: n }, n);
          })
        ),
        error ? h("span", { className: "__sm_error", role: "alert" }, messageText(t, error)) : null
      );
    }

    // ── plugin ────────────────────────────────────────────────────────────

    // Follow the host language without remounting the form or losing drafts.
    function useLocale(locale) {
      var refresh = react.useState(0)[1];
      react.useEffect(function () {
        if (!locale || typeof locale.subscribe !== "function") return;
        return locale.subscribe(function () { refresh(function (revision) { return revision + 1; }); });
      }, [locale]);
    }
    // Keep translation keys in state so feedback follows later language changes.
    function messageText(t, message) {
      if (!message) return "";
      return t(message.key) + (message.detailKey ? ": " + t(message.detailKey) : message.detail ? ": " + message.detail : "");
    }

    function apply(ctx) {
      var t = ctx.locale.bind(NS);
      ctx.effect(function () { return ctx.locale.register(NS, { zh: zh, en: en }); }, "dsh-soul-md: dictionaries");
      // ONE scope for the namespace, shared by the section and both switchers.
      // Two binds would each keep their own revision
      // bookkeeping (`pendingRevision`, write queue) over one Host document, so a
      // write from the header and one from this section could each fence against
      // a revision the other had already superseded — the Host refuses the stale
      // write and the scope still settles it as success.
      var scope = ctx.configForms.get("soul-md");
      var write = createSettingsWriter(scope);
      var heldComposers = new Set();
      function hold(sessionId, reason) {
        var conversation = typeof ctx.get === "function" ? ctx.get("conversation") : void 0;
        var release = holdComposer(conversation && conversation.blocks, sessionId, reason);
        function done() { heldComposers.delete(done); release(); }
        heldComposers.add(done);
        return done;
      }
      ctx.effect(function () {
        return function () { Array.from(heldComposers).forEach(function (release) { release(); }); };
      }, "dsh-soul-md: release composer blocks");
      ctx.slots.inject("plugins.bundle.config", function () {
        return ctx.slots.register({
          name: "plugins.bundle.config",
          key: "dsh-soul-md",
          locale: NS
        }, function (props) {
          return h(SoulSection, Object.assign({}, props, { scope: scope, write: write, t: t, locale: ctx.locale }));
        });
      });
      ctx.slots.inject("conversation.session.header.actions", function () {
        return ctx.slots.register({
          name: "conversation.session.header.actions",
          id: "soul-md-persona",
          order: 40
        }, function (props) {
          return h(PersonaSwitcher, Object.assign({}, props, { key: props.sessionId, scope: scope, write: write, t: t, locale: ctx.locale }));
        });
      });
      ctx.slots.inject("conversation.hero.options", function () {
        return ctx.slots.register({
          name: "conversation.hero.options",
          id: "soul-md-persona-hero",
          order: 40
        }, function (props) {
          return h(PersonaSwitcher, Object.assign({}, props, { key: props.sessionId, scope: scope, write: write, t: t, locale: ctx.locale, hero: true, holdComposer: hold }));
        });
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    return module.exports;
  }
});

