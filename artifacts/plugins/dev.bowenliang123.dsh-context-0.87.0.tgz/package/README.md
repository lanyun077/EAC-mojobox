![Social preview](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/social-preview.png)

# dsh-context

[简体中文](https://github.com/bowenliang123/dsh-context/blob/main/README.md) · [English](https://github.com/bowenliang123/dsh-context/blob/main/README_en.md) · [日本語](https://github.com/bowenliang123/dsh-context/blob/main/README_ja.md) · [Español](https://github.com/bowenliang123/dsh-context/blob/main/README_es.md) · [Français](https://github.com/bowenliang123/dsh-context/blob/main/README_fr.md) · [Deutsch](https://github.com/bowenliang123/dsh-context/blob/main/README_de.md) · [Русский](https://github.com/bowenliang123/dsh-context/blob/main/README_ru.md) · [Português](https://github.com/bowenliang123/dsh-context/blob/main/README_pt.md)

[![npm version](https://img.shields.io/npm/v/dsh-context)](https://www.npmjs.com/package/dsh-context)
[![GitHub stars](https://img.shields.io/github/stars/bowenliang123/dsh-context?style=social)](https://github.com/bowenliang123/dsh-context)
[![dshfind](https://dshfind.com/api/badge/bowenliang123/dsh-context)](https://dshfind.com/en/plugins/bowenliang123/dsh-context?ref=badge)

**适用于 Agent 上下文洞察与管理的最佳 [DeepSeek Harness 插件](https://www.deepseek.com/harness/)。**

> 获得 DeepSeek Harness 团队成员 [@tianyicui](https://github.com/tianyicui) 和 [@turtle1999](https://github.com/turtle1999) 推荐并加星——参见 [X 上的这条帖子](https://x.com/tianyi/status/2105256532657267119)。

[`dsh-context`](https://www.npmjs.com/package/dsh-context) 提供完整的上下文生命周期管理功能。
- **上下文洞察页面** — 跨会话总览，作为一级侧边栏面板（与 Plugins 和 Automation tasks 并列）：包含 7 天 Token/成本使用图表的 KPI 栏、活动热力图、汇总组成环形图，以及可筛选并可直接跳转至任一会话的会话卡片。
- **Context 标签页** — DeepSeek Harness 上下文统计、组成、趋势、事件、消息和命令执行的 UI 上下文仪表板。
- **Fleet 标签页** — Agent 家族专属页面：当前 Agent、它的父级，以及每个子 Agent 各自显示为一张实时卡片。
- **Context 面板** — 同一仪表板也可作为右侧边栏标签页：在侧边栏指南页面选择 **Context**，面板便会在聊天旁打开，并包含 Agent 网络。
- **`/context` 命令** — 斜杠命令会显示当前上下文组成模型和近期上下文演变。

▶️ **4 分钟视频导览** — [在 Bilibili 观看](https://www.bilibili.com/video/BV1bn4K6TEEV/)。

[![dsh-context 与 DeepSeek Harness：上下文组成、演进与多 Agent 团队](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/video-cover.jpg)](https://www.bilibili.com/video/BV1bn4K6TEEV/)

## 安装 / 更新

### 在 DeepSeek Harness 网页版或桌面版中安装

在 **Add plugin** 向导的搜索框中填写 `dsh-context`，然后点击 **Install**：

![Add_plugin_wizard](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/add-plugin-wizard.png)

### 使用 `dsh` CLI 安装

从 [DeepSeek Harness](https://www.npmjs.com/package/@deepseek-ai/dsh) 安装 [`dsh-context`](https://www.npmjs.com/package/dsh-context) 插件：

```sh
dsh plugin --profile web add dsh-context
```

或更新 `dsh-context` 插件：

```sh
dsh plugin --profile web update dsh-context@latest
```

然后使用 `dsh web` 启动 Web UI。无需构建，也无需重启。

## 使用方法

五种入口，讲述同一件事——你的 Agent 正在携带什么、它如何获得这些内容，以及它如何使用这些内容：

| 入口 | 功能 |
| --- | --- |
| **上下文洞察页面** | 一览所有会话：使用量、成本、缓存命中率、每日活动以及每个会话的上下文概况；可按时间范围、日期、分组或搜索筛选，并一键跳转。 |
| **Context 标签页** | 完整仪表板：统计、组成、逐请求趋势、事件、文件活动和命令执行——适用于每个会话。 |
| **Fleet 标签页** | Agent 网络：当前 Agent、它的父级以及所有子 Agent，实时呈现。 |
| **`/context` 命令** | 居中弹窗，提供相同的组成信息和上下文浏览器，无需离开聊天。 |
| **Preferences 卡片** | 每位用户的默认设置：面板入口、洞察时间范围、趋势与排序默认值，以及拼接在每个会话系统提示词前后的前缀/后缀。 |

## 🗂️ 上下文洞察页面

点击侧边栏面板列表中的 **Context Insights / 上下文洞察**（与 **Plugins** 和 **Automation tasks** 位于同一层级），页面便会作为完整的中央栏面板打开：

![The Context Insights page](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-dashboard.png)

| 区块 | 解答的问题 |
| --- | --- |
| **KPI 栏** | 我的使用量如何——所选时间范围（今天 / 7 天 / 30 天）内活跃的会话，其计费 Token、预估成本、缓存命中率和轮次按 step 发起日归因；工具执行与活跃时长则统计这些会话及其子 Agent 的全部生命周期，与耗时统计卡片一致。 |
| **7 天使用量图表** | 每天的花费和用量如何——最近 7 天每天的计费 Token 和预估成本以成对柱状图展示，按会话自身各请求的时间汇总（而不是按会话最后活跃日期）。 |
| **活动热力图** | 我实际在什么时候工作——最近 8 周每日的计费 Token；点击某天即可筛选当天活跃的会话，并让三个统计卡片只看当天。 |
| **技能加载** | 加载了哪些技能、各多少次、最近何时——所选时间范围内按技能汇总的加载次数；点击可筛选加载过它的会话。 |
| **工具调用** | 运行了哪些工具、各多少次、最近何时——按日账本汇总的工具执行次数；点击可筛选运行过它的会话。 |
| **命令执行** | 运行了哪些程序、各多少次、最近何时——按程序汇总的命令执行次数（按派发计）；点击可筛选执行过它的会话。 |
| **设置入口** | 页面标题栏中的按钮——与 Context 标签页 Plugin Info 卡片中通往此插件偏好设置的受保护跳转相同。 |
| **Context Composition** | 所选时间范围内的计费 Token 用在了哪里，按 Token 卡片的计费分类（Tool Calls、Reasoning、Answers……）拆分。 |
| **会话卡片** | 四个卡片下方每个会话的概况：组成环形图、计费 Token、轮次、成本以及工作区分组 / 项目路径；可按最近活动、Token 数或上下文大小排序、搜索、按工作区分组。点击卡片即可打开会话。 |

## 📊 Context 标签页

打开任意会话并点击 **Context / 上下文** 标签页：

![Context panel overview](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-overview.png)

| 卡片 | 解答的问题 |
| --- | --- |
| **Context Stats** | 轮次、步骤、用户输入、实时工具调用——以及根据 models.dev 价格列表估算的成本（将鼠标悬停在 `?` 上可查看每百万 Token 单价；仅 DeepSeek 区分高峰 / 非高峰：其挂牌价为谷时价，高峰时段按 2 倍计费）。 |
| **Token Stats** | 计费 Token 用在了哪里——总量与输入框下方聊天统计行相同，拆分为系统提示词、工具定义、用户消息、注入上下文、技能注入、工具调用、推理和回答。工具调用把工具名称与参数（提示词中重放的部分，加上输出中生成的部分）与这些工具返回的结果一并计入；回答从同一份助手内容与输出中拆出模型的回复正文；推理以同样方式拆出其思考内容；会话的缓存命中率显示在角落。 |
| **Timing Stats** | 活跃时间如何分布在模型调用、工具运行和开销之间。 |
| **Current Context** | 此刻窗口中的内容。 |
| **Context Trend** | 每个请求的大小及其变化过程。 |
| **Context Browser** | 任意请求实际由哪些内容组成。 |
| **Context Events** | 上下文窗口何时以及为何发生变化。 |
| **File Activity** | Agent 对你的文件做了什么。 |
| **命令执行** | Agent 执行了哪些命令、每次运行如何结束、主要用到了哪些程序。 |

成本估算遵循一套有文档记录的规则：[模型定价如何映射](docs/model-pricing-mapping.md)。

标题中的占用率和组成数据读取的都是与聊天输入框上下文环形图相同的**官方 Token 计量投影**（`contextPressure` / `contextBreakdown`），因此数值始终与环形图一致——卡片中的百分比就是同一占用率，精确显示到小数点后一位。

**Context Stats** 卡片中的 Agent Network 单元格（整个 Agent 家族的计费 Token 和预估成本）会跳转至 **Fleet** 标签页。输入输出一行的胶囊同样是跳转链接：**用户输入** 打开上下文浏览器的用户消息，**读取 / 写入 / 搜索 / 图片** 落到文件活动卡片并选中对应筛选。

### Context Stats

#### Token Stats 和 Timing Stats
![Token_Stats_and_Timing_Stats](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/token-stats-and-timing-stats.png)

#### Context Stats
![Context_Stats](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-stats.png)

### 🧱 当前上下文 — 此刻上下文窗口中的内容

![Current Context card](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/current-context.png)

六种颜色的堆叠条，以模型的完整窗口为基准（末尾两个带斜线的区域 = 自动压缩预留空间：先是其余量，再是请求预留的输出窗口）：系统提示词、工具定义、用户消息、注入上下文、助手回复、工具结果——每项都显示约略 Token 数和占比。当对话开始退化时，可以在这里看到*具体是哪部分*导致的。

### 📈 上下文趋势 — 按轮次或步骤查看上下文的增长与演变

![Context Trend with the step brief](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-trend.png)

每个模型请求对应一根堆叠柱——比按消息划分更细，因此可以逐轮观察窗口的增长：

- **✨ 步骤摘要** — 图表下方有三行通俗摘要：**User** 回顾开启该轮的消息，**In** 列出新加入的内容（通常是先前的工具结果），**Response** 显示回复和/或调用的工具。点击某行即可在 Context 浏览器中打开对应消息。
- **事件旗标** — 压缩、剪枝、技能注入、子智能体创建、智能体交互与模型切换，目标创建/完成、待办新增/完成、用户提问、团队任务创建/完成，以及耗时最长/新增上下文最多，都以各自的图标旗标落在对应步骤；虚线旗杆直达底部，悬停读数、点击跳到该步。总览模式把相邻事件折叠为一枚聚合旗标，点击直接回到该步。
- **按你的方式阅读** — 可选择 **Step / Turn** 粒度、**Total**（累计组成）或 **Delta**（每个请求的有符号变化），并可横向滚动查看整个会话。在 Delta 模式中，增长会堆叠在基线上方，压缩则会向下延伸：

![Context Trend in Delta mode](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/history-delta.png)

- **总览** — 一个开关即可将整个会话（步骤或轮次）压缩到面板宽度内，形成连续的堆叠带：一眼查看每次压缩造成的下降和组成变化，无需横向滚动，也无需额外加载内容。标记显示四分位点和完整范围；悬停可浏览读数，悬停某条分类带可将该分类整条点亮，点击会固定步骤并在上下文浏览器中展开该分类（与 DNA 模式和 Adaptive 互斥）。
- **悬停和固定** — 悬停可即时查看提示信息；点击可固定完整明细，并在估算值旁显示服务商报告的 **Actual Prompt / Output / Cache**。
- **实时联动** — 将鼠标悬停在柱上，可在图表旁的 Context 浏览器中预览该步骤组装的上下文；离开图表后恢复你自己的选择。

### 🧭 上下文浏览器 — 查看任意请求的内容

选择 **当前** 或任一保留的步骤，即可浏览该请求由哪些内容组成：七个可折叠类别可展开为逐项列表，每项都显示 Token 开销；每项还可再次展开，查看其**实际内容**——系统提示词、每个工具的 JSON schema、消息文本、推理内容、工具参数和工具输出。技能内容（可用技能目录、`/skill` 调用和 `skill` 工具加载）有独立的 **Skill Injections** 类别，因此隐蔽技能的上下文占用不会藏在注入上下文或工具结果类别中。

- **每种工具由谁提供** — 每行工具定义都带有尽力识别的来源标签：`tool-*` 表示一方软件包，`dsh-*` 表示功能软件包，`mcp:<server>` 表示代理，或显示由 `tools.register()` 实时监控的确切插件。可按**大小 / 名称**排序，并通过每个类别各自的可搜索字段进行筛选：

![Tool schemas with source chips, filter, and sort](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-browser-tools.png)

- **按类型筛选助手回复** — 助手类别的搜索框包含 **Thinking / Tools / Answer** 标签，每个标签显示当前搜索结果中该类型的回复数（一次回复可包含多种类型）；点击某个标签即可只保留匹配的回复，再次点击可清除筛选：

![Assistant replies with kind filter chips](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-browser-assistant-kinds.png)

- **展开工具结果可查看完整调用** — 工具名称、参数及其 **OK/error** 状态，以及带行数和 **Raw / Markdown** 切换的结果正文：

![A tool result expanded with Raw/Markdown toggle](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-browser-tool-result.png)

- **附件按顺序显示为卡片** — 消息中的 `image` 和 `file` 区块会按消息中的顺序排列在一起，每个区块对应一张卡片：图片显示缩略图、尺寸、存储大小和 DeepSeek 官方图像 Token 估算；其他文件显示类型图标、扩展名和存储大小。点击一次即可在 dsh 自带的预览栏中打开附件（支持 Markdown、代码、PDF、Office 和图片查看器），并使用文件的真实名称：

![Image attachment cards with their dimensions, stored size, and token estimate](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-browser-images.png)

- **与上一轮对比** — 各类别的有符号差异徽标（`+N` 项、`±Nk` Token）让你一眼看出某轮新增或回收了什么。压缩前的旧步骤会从已移除消息存档中重建；若某步骤的组成仅为近似值，卡片会明确说明。

- **DNA 模式将上下文平铺展开** — 条形图按模型读取顺序逐项绘制色带，下方把同样的内容铺成一张平铺列表，最新的消息在最上（模型按从旧到新读取，列表即该顺序的倒排）：每行带有其在提示词中的位置（`#12`）、类别、引入步骤和 Token 开销，展开后可见同样的完整内容；工具定义与系统提示词作为两个分组行收尾。卡片与旁边的组成卡片、趋势卡片等高收尾——完整平铺的会话在卡片内滚动，而不会淹没整个页面。

### ⚡ 上下文事件 — 上下文窗口何时以及为何发生变化

![Context Events with a compaction](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-events.png)

每次注入、压缩、清理、模型切换和计划模式切换都会记录，并标注其来源（指令文件、插件 ID、技能名称）、Token 净变化量（压缩事件会显示回收量）、轮次 / 步骤和时间。**全部 / 注入 / 压缩 / 剪枝 / 切换模型** 标签可单选按类型筛选日志，每个标签都显示整个会话的对应事件总数。

### 📁 文件活动 — Agent 对文件做了什么

![File Activity](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/file-activity.png)

每个被操作的文件显示一行——读取、写入或搜索；数据会汇总至趋势图中所选的步骤：

- **按用途统计数量**，标题栏标签也可用作筛选器（**Read / Written / Searched / Images**），并提供路径搜索框。
- **行数变化** — 每个 `edit` / `write` 操作都会计入估算的 `+新增 / −删除` 行数，可查看单个文件及汇总值。
- **所有模式均计入** — 原生工具、Minimal 预设的 `str_replace_editor`，以及 PTC `run_code` 程序中的嵌套调用，都会汇总到各工具对应的行中。
- **搜索结果对应实际文件** — 匹配的文件会有自己的操作行，并显示命中次数。
- **点击一行**可展开完整操作日志——每个操作都可直接跳转到 Context 浏览器中对应的工具结果。
- **点击文件名**可在右侧 Sidebar 中打开文件预览，与内置 Files 侧边栏的行为完全相同——使用相同的查看器和每个文件独立的标签页。如果 Harness 没有该栏，则文件名仍会像以前一样在系统中打开。

### 🖥️ 命令执行 — Agent 跑了什么

![Command Executions](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/command-executions.png)

每次 Shell 和代码执行的状态、墙钟耗时与步骤定位，附带会话摘要、值得注意的快捷入口和程序分布。值得注意的事项与程序分布始终保持全局，只有搜索与状态筛选在收窄右侧列表。左侧每次点击都会把对应视角写入过滤框：点击程序会填入名称并高亮该行，再次点击则同时清除两者——过滤框始终反映当前生效的筛选。

## 🚢 编队 Tab

打开任意会话，点击 **编队** Tab（**上下文** 右侧）——在一个独立页面查看 Agent 家族：顶部摘要条，下方是 **Agent 网络** 与 **跨 Agent 协作**，再往下是 **协作任务** 与 **事件检查**。

![6 个 Agent 的编队总览：编队摘要、Agent 网络、跨 Agent 协作、协作任务与事件检查](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/fleet-overview.png)

摘要条统计 Agent 数、运行中、工作项与消息；在关系图或泳道中选中某个 Agent，协作视图会收窄到该成员，页面始终只回答一个成员的情况。

### 🕸 Agent 网络 —— 家族全景

当前 Agent、其父级与每个子 Agent —— 每个 Agent 一张卡片：标题、实时上下文大小与窗口占用、构成条，以及运行时长和步数。连线从每个父级按谱系颜色展开——悬停卡片会点亮整条链路，并在详情条中显示完整拆分；点击节点会高亮该节点。运行中的 Agent 在入边上有绿色脉冲，标题旁转动 harness 自己的滚动加载指示器；完成后落定为与头部子 Agent 列表相同的绿点。窄面板会把家族折成整齐的行——绝不出现横向滚动条。

### 🛰 跨 Agent 协作 —— 家族在同一条时间线上

协作卡片为每个 Agent 铺一条泳道，把消息流、任务标记与委派记录放到同一条时间线上；安静的泳道可一键收起。任务编号在泳道间标识同一个任务——重复编号即同一任务——悬停会联动相关记录。**最早 / 最新** 可切换顺序，搜索框收窄泳道；点击任务可筛选时间线并定位该任务。

### ✅ 协作任务 —— 谁在做什么

**协作任务** 面板把团队任务与子 Agent 委派放在同一处——所属分组、状态筛选（全部 / 进行中 / 待处理 / 已完成），以及聚焦任务时点亮整条前置依赖链的 blocked-by 链接。每张卡片带有归属 Agent、任务简报、写入范围与最终回报；点击任务可在原处展开完整描述，支持原文或渲染视图。

### 📡 事件检查 —— 谁对谁说了什么

**事件检查** 卡片自动读取家族的会话日志——无需扫描步骤。消息、报告与委派记录汇入同一条可筛选的流：选择时间线节点或流中记录即可查看完整记录——它来自哪个会话日志及其序号、何时由运行时而非子 Agent 写入结算、完整收尾报告（含结构化结果或诊断），以及可打开该 Agent 侧边栏聊天或完整视图的参与者卡片。可按类型或文本筛选，共享的 Agent 选择会收窄整个中枢。

右侧边栏的 **上下文** 面板也内嵌同一张卡片，阅读聊天时家族始终一键可达。完全不需要这个 Tab？在偏好设置卡片中关闭 **编队 Tab**——卡片会继续留在该面板中，上下文 Tab 的家族单元会在有侧边栏时打开它。

## ⌨️ `/context` 命令

输入 `/context`（或从 `/` 菜单中选择），然后按 Enter：

![Slash menu with the context command](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-command-entry.png)

居中对话框会显示 **Current Composition** 卡片和 **Context browser**——与标签页相同的组成条、逐步选择器和 `vs previous turn` 差异徽标：

![The /context modal](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/context-command.png)

## ⚙️ 设置

**Context** 偏好设置卡片保存此插件的用户级设置——**上下文面板入口**（**Context** 会话标签页、右侧 Sidebar 面板、两者，或隐藏——隐藏后回复行的跳转按钮也随之隐藏）、**Fleet** 标签页自身的显示 / 隐藏开关（不受上下文面板入口影响）、**上下文洞察**页面的默认时间范围（今天 / 近 7 天 / 近 30 天，默认近 30 天；在页面上点击时间范围预设会写回此项）、趋势粒度（Step/Turn）、趋势模式（Total/Delta）、默认显示的趋势时长曲线、趋势自动总览阈值、Context Browser 对比基线、工具和 File Activity 排序，以及上下文洞察的显示 / 隐藏开关。该卡片位于 **Plugins** 页面：侧边栏的 **Plugins** 入口 → **dsh-context** 插件包页面 → **Configuration** 区域（卡片由该入口的实时 Config 表单提供）。

**System Prompt · Prefix / Suffix** 行用于填写自由文本，并将其拼接到每个会话系统提示词的最前面 / 最后面，对所有 Agent（包括子 Agent）生效——它们是随 Harness 自身提示词组装流程一同应用的部署级角色设定或行为规则。修改从下一轮开始生效；将某行留空即可停用对应设置。

上下文洞察的时间范围预设按钮会把选择写回为默认值；其余图表和卡片中的切换项仅对当前视图生效，不会覆盖已保存的偏好设置。

![The Context settings card](https://raw.githubusercontent.com/bowenliang123/dsh-context/main/docs/settings.png)

## 注意事项

- **缓存占用** — 插件只把每个会话的精简摘要（组成、计数、成本/耗时、模型信息）写入 dsh 的投影缓存；体量较大的逐事件明细（surface 文本、请求拆分、文件操作、命令程序、span）会在面板需要时从持久日志重新汇总，因此即使会话很长，缓存也能保持很小。明细视图会从持久日志分段加载完整的请求、轮次、事件、surface 节点、存档、文件操作、命令与 span，并在打开对应卡片时按需加载。
- **估算值与实际值** — 各类别数值采用 dsh 自身的固定密度启发式算法（与内置 Token 计量器相同）；在趋势图中固定某一步后，其明细会在估算值旁显示服务商报告的实际值，而 Token 卡片则将 ≈ 估算的组成占比与服务商精确报告的计费总量并列呈现。
- **兼容性** — 通过同一条由数据形状驱动的代码路径，支持 V4 会话日志格式的 `@deepseek-ai/dsh` **0.2.0-rc.2 及更高版本**（`0.2.0` 与 `0.2.1` 系列已在各自的 rc.2 版本上验证，`0.2.2` 系列已在 rc.1 与 rc.3 版本上验证）。各版本支持情况及验证方式见：[docs/compatibility.md](docs/compatibility.md)。
- **国际化** — UI 支持简体中文、英语、日语、西班牙语、法语、德语、俄语和葡萄牙语（切换语言需 dsh 0.2.2+；更早的支持版本仅提供中文和英语）。

## 喜欢它？

如果 `dsh-context` 帮你了解 Agent 正在携带哪些内容，欢迎在 [GitHub](https://github.com/bowenliang123/dsh-context) 点亮 ⭐——也欢迎提交 issue / PR！

## 许可证

[Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0)
